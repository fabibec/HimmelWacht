import re
import asyncio
import aiohttp
from aiortc import RTCPeerConnection, RTCConfiguration, RTCIceServer, RTCSessionDescription
import os
os.add_dll_directory("C:/Program Files/gstreamer/1.0/msvc_x86_64/bin")
import cv2
import time 
import numpy as np
from datetime import datetime, timedelta
from av import VideoFrame, codec
from datetime import datetime, timedelta
from ultralytics import YOLO
import torch
import torch.version
import paho.mqtt.client as mqtt
import subprocess
import websockets
import json
from loguru import logger


# **************************************CONSTANTS AND GLOBALS**************************************
WHEP_URL = 'http://172.16.9.13:8889/stream/whep'

X_ANGLE = 0
Y_ANGLE = 0

bb_x = 0
bb_y = 0
bb_w = 0
bb_h = 0


# **************************************SETUP AI MODEL**************************************
device = 'cuda' if torch.cuda.is_available() else 'cpu'
print(f"Using device: {device}")
model = YOLO('yolov8n_custom.pt')
model.to(device)
model.eval()  # Set the model to evaluation mode 


# **************************************MQTT SETUP**************************************
client = mqtt.Client(callback_api_version=mqtt.CallbackAPIVersion.VERSION2)
client.connect("127.0.0.1", 1883, 60)


# **************************************WEBSOCKET SETUP**************************************
websocket_client = None


# **************************************CODE AND FUNCTIONS**************************************

async def run_track(track):
    start_time = time.time()
    global websocket_client
    global bb_x
    global bb_y
    global bb_w
    global bb_h
    print("Connection established at %s" % time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
    while True:
        frame = await track.recv()
        if frame is None:
            break
        # convert to OpenCV format
        frame = frame.to_ndarray(format="rgb24")
        logger.info(frame.shape)
        frame = cv2.cvtColor(frame, cv2.COLOR_RGB2BGR)
        # display the frame
        current_time = datetime.now()
        new_time = current_time - timedelta( seconds=55)
        timestamp = new_time.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
        
        #Run regular Inference on captured frame
        results = model(frame, device=device, conf=0.95, iou=0.45, agnostic_nms=True, max_det=1000)

        annotated_frame = results[0].plot()
        img = cv2.circle(annotated_frame,(310,397), 5, (0,0,255), 3)

        boxes = results[0].boxes

        # Print coordinates only if objects are detected
        if boxes is not None and len(boxes) > 0:
            for i, box in enumerate(boxes):
                coords = box.xyxy[0].cpu().numpy()
                x1, y1, x2, y2 = coords
                x1 = int(x1)
                y1 = int(y1)
                x2 = int(x2)
                y2 = int(y2)

                bb_x = x1
                bb_y = y1
                bb_w = x2 - x1
                bb_h = y2 - y1

                center_x = (x1 + x2) / 2
                center_y = (y1 + y2) / 2
                center = [int(center_x), int(center_y)]
                            



                
                print(f"Box {i}: x1={int(x1)}, y1={int(y1)}, x2={int(x2)}, y2={int(y2)}")

        else:
            bb_x = 0
            bb_y = 0
            bb_w = 0
            bb_h = 0
             



        cv2.imshow("Frame", img)


        if cv2.waitKey(1) & 0xFF == ord('q'):
            await track.stop()
            cv2.destroyAllWindows()
            print("Connection closed at %s" % time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()))
            print("time elapsed: %.2f seconds" % (time.time() - start_time))
            break
        await asyncio.sleep(0.01)
        

async def websocket_handler(websocket):
    logger.debug("websocket handler invoked")
    
    message = { 
                "boxes": [
                        {
                        "x": bb_x,
                        "y": bb_y,
                        "width": bb_w,
                        "height": bb_h
                        }
                    ]
                }
    
    await websocket.send(json.dumps(message))
    await asyncio.sleep(0.1)


async def main():
    server = await websockets.serve(websocket_handler, "0.0.0.0", 8001)
    logger.info("WebSocket server started on ws://0.0.0.0:8001")
    async with aiohttp.ClientSession() as session:
        # get ICE servers
        iceServers = []
        async with session.options(WHEP_URL) as res:
            for k, v in res.headers.items():
                if k == "Link":
                    m = re.match('^<(.+?)>; rel="ice-server"(; username="(.*?)"; credential="(.*?)"; credential-type="password")?', v)
                    iceServers.append(RTCIceServer(urls=m[1], username=m[2], credential=m[3], credentialType='password'))

        # setup peer connection
        pc = RTCPeerConnection(RTCConfiguration(iceServers=iceServers))
        pc.addTransceiver('video', direction='recvonly')

        # on connection state change callback
        @pc.on("connectionstatechange")
        async def on_connectionstatechange():
            print("Connection state is %s" % pc.connectionState)

        # on track callback
        @pc.on('track')
        async def on_track(track):
            print('on track')
            task = asyncio.ensure_future(run_track(track))

        # generate offer
        offer = await pc.createOffer()
        await pc.setLocalDescription(offer)

        # send offer, set answer
        async with session.post(WHEP_URL, headers={'Content-Type': 'application/sdp'}, data=offer.sdp) as res:
            answer = await res.text()
        await pc.setRemoteDescription(RTCSessionDescription(sdp=answer, type='answer'))

        

        await asyncio.sleep(10000)

asyncio.run(main())